# Al-Israa QC Manager 2.0.0 — Mobile Results Candidate

## Included
- Vertical, card-based QC result panel with accepted / warning / rejected states.
- Visible per-level reading, Mean, SD, Z-score, rule evidence, and an in-run Z-score plot.
- Compact horizontally scrollable navigation on mobile; prevents the tall oversized navigation seen on iPhone.
- Existing IndexedDB database name and version are unchanged to avoid destructive migration.
- Existing material, target, run, policy, and audit stores are retained.

## Important limitations
- The chart in this candidate plots the levels in the current run; it is not a historical Levey–Jennings chart. A true Levey–Jennings chart needs chronological QC history per target/level and is not represented as complete here.
- Rule evaluation remains subject to the existing QC engine implementation and requires scientific validation, particularly multi-level and chronological Westgard interpretation.
- This candidate has not been tested on the user's iPhone/Cloudflare deployment. Do not use it for patient-result release decisions until locally validated.
- No database stores are deleted or renamed. Nevertheless, export a JSON backup before replacing deployed assets.
