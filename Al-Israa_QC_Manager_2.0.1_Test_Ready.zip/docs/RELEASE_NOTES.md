# Release notes

## 1.0.0 — Unified local trial candidate
- Unified Arabic RTL responsive PWA interface.
- Device and QC material/LOT/level/target registers.
- Manual approval gate for QC targets before runs.
- Multi-level QC run capture in one run.
- Device/analyte-specific Westgard policy records and snapshots.
- Initial 1_2S, 1_3S, 2_2S, R_4S, 4_1S and 10X evaluation functions.
- APS/TEa registry, manual approval, Bias and Sigma calculators.
- Calibration and EQA documentation registers.
- Manual scientific update register.
- Local audit events and JSON backup/restore.
- PWA icons, offline shell cache and iPhone install guide.
- PostgreSQL schema draft and validation plan.

## Known exclusions
No Supabase connection, cloud synchronization, user authentication, role enforcement, protected server audit, automatic source monitoring, direct analyzer/EQA integration, or clinical validation.


## 1.3.0 — تقليل أخطاء إدخال أهداف QC
- اختيار المستوى من قائمة Level 1 / Level 2 / Level 3 مع خيار مستوى مخصص.
- اختيار الوحدة من قائمة وحدات شائعة مع خيار وحدة مخصصة عند الحاجة.
- تبقى أسماء التحاليل كما في نشرة الشركة دون فرض أسماء قياسية.
- تم تغيير إصدار ذاكرة Service Worker لإجبار التطبيق المثبت على جلب ملفات الواجهة الجديدة عند تفعيل العامل الجديد.
